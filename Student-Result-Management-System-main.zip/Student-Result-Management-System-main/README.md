# Student Result Management System
 
